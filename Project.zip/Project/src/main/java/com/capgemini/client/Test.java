package com.capgemini.client;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.beans.Address;
import com.capgemini.beans.Admin;
import com.capgemini.beans.Cart;
import com.capgemini.beans.Category;
import com.capgemini.beans.Customer;
import com.capgemini.beans.Image;
import com.capgemini.beans.Merchant;
import com.capgemini.beans.Order;
import com.capgemini.beans.Product;
import com.capgemini.beans.Review;
import com.capgemini.beans.WishList;

public class Test {
	
	public static void main(String[] args) {
		
		Admin admin=new Admin();
		admin.setCreateDate(new Date());
		admin.setName("CapStore");
		admin.setEmail("capstore@capgemini.com");
		admin.setMobile("9246100100");
		admin.setPassword("password");
		
		Address address=new Address();
		address.setAddressLine("2-92/2");
		address.setCity("pune");
		address.setCountry("India");
		address.setCreateDate(new Date());
		address.setState("MH");
		address.setZipcode("411057");
		
		Image image1=new Image();
		image1.setImageURL("SamsungHeadset.jpg");
		
		Review review1=new Review();
		review1.setCreateDate(new Date());
		review1.setCreateDate(new Date());
		
		Product product =new Product();
		product.setName("Samsung HeadSet");
		product.setCost(5000);
		product.setDiscount(25);
		product.setDescription("Samsung 3D Audio sound headSet with 3.2mm jack.");
		product.setCreateDate(new Date());
		product.setQuantity(5);
		product.setRating(0);
		product.getImages().add(image1);
		product.getReviews().add(review1);
		product.setCreateDate(new Date());
		
		Order order=new Order();
		order.setCreateDate(new Date());
		order.setOrderDate(new Date());
		order.setStatus("In Progress");
		order.getProducts().add(product);
		
		
		Category category1=new Category();
		category1.setCreateDate(new Date());
		category1.setCategoryName("Electronic");
		category1.getProducts().add(product);
		
		product.getCategories().add(category1);
		
		Cart cart=new Cart();
		cart.setCreateDate(new Date());
		cart.getProducts().add(product);
		
		WishList wishlist=new WishList();
		wishlist.setCreateDate(new Date());
		wishlist.getProducts().add(product);
		
		Merchant merchant=new Merchant();
		merchant.setCreateDate(new Date());
		merchant.setEmail("merchant@capgemini.com");
		merchant.setMobile("9052501684");
		merchant.setName("Samsung");
		merchant.setPassword("password");
		merchant.getProducts().add(product);
		
		Customer customer=new Customer();
		customer.setCreateDate(new Date());
		customer.getAddresses().add(address);
		customer.setCart(cart);
		customer.setDOB(new Date());
		customer.setEmail("aslam.d@capgemini.com");
		customer.setMobile("9246100100");
		customer.setName("Aslam");
		customer.getOrders().add(order);
		customer.setPassword("password");
		customer.setWishList(wishlist);
		
		order.getCustomers().add(customer);
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("hello");
		
		EntityManager em=emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(admin);
		em.persist(merchant);
		em.persist(customer);
		em.getTransaction().commit();
		
	}
}
