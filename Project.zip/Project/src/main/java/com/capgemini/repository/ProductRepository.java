package com.capgemini.repository;

import java.util.Set;

import com.capgemini.beans.Order;

public interface ProductRepository {

	Set<Order> getAllOrdersOfParticularProduct(String productName) ;
}
