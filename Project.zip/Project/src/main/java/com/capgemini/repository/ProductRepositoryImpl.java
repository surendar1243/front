package com.capgemini.repository;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.capgemini.beans.Order;
import com.capgemini.beans.Product;

public class ProductRepositoryImpl implements ProductRepository {
	
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("hello");
	
	EntityManager entityManager=entityManagerFactory.createEntityManager();

	public Set<Order> getAllOrdersOfParticularProduct(String productName) {
		
		TypedQuery<Product> query=entityManager.createQuery("SELECT order FROM Order order",Product.class);
		List<Product> products=query.getResultList();
		
		Set<Order> orders=new HashSet<Order>();
		
		for(Product product:products){
			if(product.getName().equals(productName)){
				
				orders=product.getOrders();
			}
		}
		
		if(orders.size()>0){
			return orders;
		}
		
		return null;
	}

}
