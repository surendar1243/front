package com.capgemini.service;

import java.util.HashSet;
import java.util.Set;

import com.capgemini.beans.Order;
import com.capgemini.repository.ProductRepository;

public class ProductServiceImpl implements ProductService {
	
	ProductRepository productRepository;
	
	

	public ProductServiceImpl(ProductRepository productRepository) {
		super();
		this.productRepository = productRepository;
	}



	public Set<Order> getAllOrdersOfParticularProduct(String productName) {
		
		Set<Order> orders=new HashSet<Order>();
		if(productName!=null){
			
			orders=productRepository.getAllOrdersOfParticularProduct(productName);
		}
		
		if(orders.size()>0){
			return orders;
		}
		return null;
	}

}
