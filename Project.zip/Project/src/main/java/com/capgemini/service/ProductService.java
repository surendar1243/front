package com.capgemini.service;

import java.util.Set;

import com.capgemini.beans.Order;

public interface ProductService {

	Set<Order> getAllOrdersOfParticularProduct(String productName);
}
