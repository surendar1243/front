/**
 * Created by ttandale on 6/30/2016.
 */
var app1=angular.module("display",[]);
